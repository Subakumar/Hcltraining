package hcl4;

public class Arg {
	
private Long over;
private Long balls;
private Long runs;
private String batsman;
private String bowler;
private String nonStriker;

public Arg() {
	
}

public Arg(Long over, Long balls, Long runs, String batsman, String bowler, String nonStriker) {
	super();
	this.over = over;
	this.balls = balls;
	this.runs = runs;
	this.batsman = batsman;
	this.bowler = bowler;
	this.nonStriker = nonStriker;
}

public Long getOver() {
	return over;
}

public void setOver(Long over) {
	this.over = over;
}

public Long getBalls() {
	return balls;
}

public void setBalls(Long balls) {
	this.balls = balls;
}

public Long getRuns() {
	return runs;
}

public void setRuns(Long runs) {
	this.runs = runs;
}

public String getBatsman() {
	return batsman;
}

public void setBatsman(String batsman) {
	this.batsman = batsman;
}

public String getBowler() {
	return bowler;
}

public void setBowler(String bowler) {
	this.bowler = bowler;
}

public String getNonStriker() {
	return nonStriker;
}

public void setNonStriker(String nonStriker) {
	this.nonStriker = nonStriker;
}


}
