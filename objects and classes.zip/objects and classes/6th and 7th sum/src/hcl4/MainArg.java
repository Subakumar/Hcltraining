package hcl4;

public class MainArg {

	public static void main(String[] args) {
		Arg a1 = new Arg();
		a1.setOver(1L);
		a1.setBalls(1L);
		a1.setRuns(4L);
		a1.setBatsman("MS Dhoni");
		a1.setBowler("Dale steyn");
		a1.setNonStriker("Suresh Raina");
		
		System.out.println("Enter the over:"+a1.getOver());
		System.out.println("Enter the balls:"+a1.getBalls());
		System.out.println("Enter the runs:"+a1.getRuns());
		System.out.println("Enter the batsman:"+a1.getBatsman());
		System.out.println("Enter the bowler:"+a1.getBowler());
		System.out.println("Enter the nonStriker:"+a1.getNonStriker());
		

	}

}
