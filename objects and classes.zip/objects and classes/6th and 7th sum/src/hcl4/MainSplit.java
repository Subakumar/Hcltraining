package hcl4;
import java.util.*;

public class MainSplit {

	public static void main(String[] args) {
		Split s1 = new Split();
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the sentence:");
		String s=sc.nextLine();
		String str[] = s.split("#");
		String name= str[0];
		s1.setName(name);
		long runs = Long.parseLong(str[1]);
		s1.setRuns(runs);
		System.out.println("Extra Type Details");
		System.out.println("Extra Type:"+s1.getName());
		System.out.println("Extra Type:"+s1.getRuns());
		
		
		
		
		
		
	}

}
