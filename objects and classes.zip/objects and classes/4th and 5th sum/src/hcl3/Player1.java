package hcl3;

public class Player1 {
 private String playername;
 private String countryname;
 private String skill;
 Player1(){
	 
 }
public Player1(String playername, String countryname, String skill) {
	super();
	this.playername = playername;
	this.countryname = countryname;
	this.skill = skill;
}
public String getPlayername() {
	return playername;
}
public void setPlayername(String playername) {
	this.playername = playername;
}
public String getCountryname() {
	return countryname;
}
public void setCountryname(String countryname) {
	this.countryname = countryname;
}
public String getSkill() {
	return skill;
}
public void setSkill(String skill) {
	this.skill = skill;
}

}
 

