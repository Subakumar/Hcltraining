package hcl3;
import java.util.*;
public class MainPlayer1 {

	public static void main(String[] args) {
		Player1 p1= new Player1();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the details:");
		String s= sc.nextLine();
		String str[]=s.split(",");
		for(String string: str)
		p1.setPlayername(str[0]);
		p1.setCountryname(str[1]);
		p1.setSkill(str[2]);
		
		
		
		System.out.println("Enter Player Name:"+p1.getPlayername());
		System.out.println("Enter Country Name:"+p1.getCountryname());
		System.out.println("Enter Skill:"+p1.getSkill());
		
		
	}

}
