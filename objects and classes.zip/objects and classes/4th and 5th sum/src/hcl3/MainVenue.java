package hcl3;
import java.util.*;

public class MainVenue {

	public static void main(String[] args) {
		Venue v1 = new Venue();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Venue Name:");
		
		String venue = sc.nextLine();
		v1.setName(venue);
		System.out.println("Enter the city name:");
		
		String city = sc.nextLine();
		v1.setCity(city);
		System.out.println("Enter the venue Details:");
		System.out.println("Enter the venue name:"+v1.getName());
		System.out.println("Enter the city name:"+v1.getCity());
		v1.menu();
		
		
		int i=0;
	      while(i<3) {
	    	  System.out.println("Enter the a:");
	    	  int a=sc.nextInt();
	    	  switch(a) {
	    	  case 1:
	    		  System.out.println("enter venue name: ");
	    		  sc.nextLine();
	    		  String venue1=sc.nextLine();
	    		  v1.setName(venue1);
	    		
	              System.out.println("venue details");
	    		    System.out.println("venue name: "+v1.getName());
	    		  System.out.println("venue city: "+v1.getCity());
	    		  v1.menu();
	    		
	    		  break;
	    	  case 2:
	    		  System.out.println("enter city name: ");
	    		  sc.nextLine();
	    		  String city1=sc.nextLine();
	    		  v1.setCity(city1);
	    		 
	    		  System.out.println("venue details");
	    		  System.out.println("venue name: "+v1.getName());
	    		  System.out.println("venue city: "+v1.getCity());
	    		  v1.menu();
	    		  break;
	    	  case 3:
	    		  
	    		
	    		  System.out.println("venue details");
	    		  System.out.println("venue name: "+v1.getName());
	    		  System.out.println("venue city: "+v1.getCity());
	    		  
	    		  break;
	    	  }
	    		  
	    		  i++;
	    	  }
	      }
}
	      
	      
