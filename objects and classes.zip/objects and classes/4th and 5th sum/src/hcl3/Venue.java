package hcl3;

public class Venue {

	private String name;
	private String city;
	
	public Venue(){
		
	}

	public Venue(String name, String city) {
		super();
		this.name = name;
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	void menu() {
	System.out.println("Verify and Update Venue Details");
	System.out.println("1.Update Venue Name");
	System.out.println("2.Update city Name");
	System.out.println("3.All information correct/exit");
	
	
}
}
