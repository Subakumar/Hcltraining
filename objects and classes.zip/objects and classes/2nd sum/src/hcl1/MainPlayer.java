package hcl1;


public class MainPlayer {

	public static void main(String[] args) {

HclPlayer h1= new HclPlayer();
h1.setPlayername("MS Dhoni");
h1.setCountryname("India");
h1.setSkill("All Rounder");



System.out.println("Player Details:");
System.out.println("Player Name:"+ h1.getPlayername());
System.out.println("Country Name:"+ h1.getCountryname());
System.out.println("Skill:"+ h1.getSkill());
}
}
	