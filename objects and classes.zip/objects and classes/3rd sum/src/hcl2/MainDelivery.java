package hcl2;
public class MainDelivery {

	public static void main(String[] args) {
		HclDelivery h2 = new HclDelivery();
		h2.setOver(1L);
		h2.setBalls(1L);
		h2.setRuns(4L);
		h2.setBatsman("MS Dhoni");
		h2.setBowler("Dale Steyn");
		h2.setNonstriker("Suresh Raina");
		
				System.out.println("Delivery Details:");
				h2.deliveryDetails();
				

	}

}