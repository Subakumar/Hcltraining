package hcl2;

public class HclDelivery {
	
	private Long over;
	private Long balls;
	private Long runs;
	private String batsman;
	private String bowler;
	private String nonstriker;
	public HclDelivery() {
		
	}
	public HclDelivery(Long over, Long balls, Long runs, String batsman, String bowler, String nonstriker) {
		super();
		this.over = over;
		this.balls = balls;
		this.runs = runs;
		this.batsman = batsman;
		this.bowler = bowler;
		this.nonstriker = nonstriker;
	}
	public Long getOver() {
		return over;
	}
	public void setOver(Long over) {
		this.over = over;
	}
	public Long getBalls() {
		return balls;
	}
	public void setBalls(Long balls) {
		this.balls = balls;
	}
	public Long getRuns() {
		return runs;
	}
	public void setRuns(Long runs) {
		this.runs = runs;
	}
	public String getBatsman() {
		return batsman;
	}
	public void setBatsman(String batsman) {
		this.batsman = batsman;
	}
	public String getBowler() {
		return bowler;
	}
	public void setBowler(String bowler) {
		this.bowler = bowler;
	}
	public String getNonstriker() {
		return nonstriker;
	}
	public void setNonstriker(String nonstriker) {
		this.nonstriker = nonstriker;
	}
	
	public void deliveryDetails() {
	System.out.println("over:"+getOver());
	System.out.println("runs:"+getRuns());
	System.out.println("balls:"+getBalls());
	System.out.println("Batsman:"+getBatsman());
	System.out.println("Bowler:"+getBowler());
	System.out.println("NonStriker:"+getNonstriker());


	}

		
	}
	


