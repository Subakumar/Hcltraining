package venue;

public class Venue2 {

	public static void main(String[] args) {
		Ven1 ve = new Ven1();
		ve.setCity("chennai");
		ve.setName("M.A.Chidambaram Stadium");
		System.out.println("Venue Details:");
		System.out.println("city name:" +(ve.getCity()) +"\n"+"Venue Name:" +(ve.getName()) +"\t");

	}

	

}
