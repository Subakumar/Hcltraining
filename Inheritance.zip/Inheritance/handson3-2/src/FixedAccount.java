
public class FixedAccount extends SavingsAccount{
int lockingperiod;
double minimumbalance,balance;
String accountNumber, accountHolderName;;


public FixedAccount() {
	
}

public FixedAccount(int lockingperiod,double minimumbalance,double balance,String accountNumber, String accountHolderName) {
	super();
	this.lockingperiod = lockingperiod;
}

public int getLockingperiod() {
	return lockingperiod;
}

public void setLockingperiod(int lockingperiod) {
	this.lockingperiod = lockingperiod;
}

}
