
public class SavingsAccount extends Acc1 {
 double minimumbalance,balance;
 String accountNumber, accountHolderName;

 public SavingsAccount(){
	 
 }

public SavingsAccount(double minimumbalance) {
	super();
	this.minimumbalance = minimumbalance;
}

public double getMinimumbalance() {
	return minimumbalance;
}

public void setMinimumbalance(double minimumbalance) {
	this.minimumbalance = minimumbalance;
}

}
