import java.util.*;
public class MainShape {

	public static void main(String[] args) {
		Area a = new Area();
		Circle c = new Circle();
		Rectangle R = new Rectangle();
		Triangle T = new Triangle();
		
		Scanner s = new Scanner(System.in);
		int i =0;
		while(i<3) {
		System.out.println("enter the n:");
		int n = s.nextInt();
		switch(n) {
		case 1:
			System.out.println("enter the rad:");
			double radius= s.nextDouble();
			c.setRadius(radius);
			c.computeArea();
			break;
		case 2:
			System.out.println("enter the length:");
			double length = s.nextDouble();
			s.nextLine();
			System.out.println("enter the breadth:");
			double breadth = s.nextDouble();
			s.nextLine();
			R.setBreadth(breadth);
			R.setLength(length);
			
			R.computeArea();
			break;
			
		case 3:
			
			System.out.println("enter the height:");
			double height = s.nextDouble();
			s.nextLine();
			System.out.println("enter the base:");
			double base = s.nextDouble();
			s.nextLine();
			T.setHeight(height);
			T.setBase(base);
			T.computeArea();
			
			break;
			
		}
		i++;
		}
	}

}
