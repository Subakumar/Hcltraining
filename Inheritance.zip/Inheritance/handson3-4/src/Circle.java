
public class Circle extends Area {
 double radius ;
 public Circle() {
	 
 }
public Circle(double radius) {
	super();
	this.radius = radius;
}
public double getRadius() {
	return radius;
}
public void setRadius(double radius) {
	this.radius = radius;
}
 public void computeArea() {
	 area = 3.14*(radius*radius);
	 System.out.println("area of circle:"+area);
 }
}
