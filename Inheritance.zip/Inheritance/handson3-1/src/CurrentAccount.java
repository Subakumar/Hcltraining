
public class CurrentAccount extends Acc {
	String tinnumber;
	
	public CurrentAccount() {
		
	}
	public CurrentAccount( String accname,String accno, String bankname,String tinnumber) {
		super( accname,  accno, bankname);
		this.tinnumber = tinnumber;
	}
	public String getTinnumber() {
		return tinnumber;
	}
	public void setTinnumber(String tinnumber) {
		this.tinnumber = tinnumber;
	}
	void display() {
		super.display();
		System.out.println("TIN NUMBER:"+getTinnumber());
	}
	
}
