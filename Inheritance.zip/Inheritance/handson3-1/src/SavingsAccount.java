
public class SavingsAccount extends Acc {
	
		 String orgName;
		public SavingsAccount() {
			
		}

		public SavingsAccount( String accname,String accno, String bankname,String orgName) {
			super(accname,  accno, bankname);
			this.orgName = orgName;
		}

		public String getOrgName() {
			return orgName;
		}

		public void setOrgName(String orgName) {
			this.orgName = orgName;
		}
		void display() {
			super.display();
			System.out.println("Organisation Name:"+getOrgName());
		}
		
}
