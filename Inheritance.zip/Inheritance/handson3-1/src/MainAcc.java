import java.util.*;

public class MainAcc {

	public static void main(String[] args) {
Scanner sc = new Scanner(System.in);


	System.out.println("choose account type:");
	System.out.println("1.Savings Account");
	System.out.println("2.Current Account");
	System.out.println("enter the n:");
	int n = sc.nextInt();
	sc.nextLine();
switch(n) {
case 1:
	
	
	System.out.println("enter account details in comma separated(account name, account no,bankname,organisation name");
	System.out.println("enter the details:");
	
	String details= sc.nextLine();
	sc.nextLine();
	String str[] = details.split(",");
	
	Acc a = new SavingsAccount(str[0],str[1],str[2],str[3]);
	
	a.display();
	break;
	
	
case 2:
	System.out.println("enter account details in comma separated(account name, account no,bankname, tinnumber");
	System.out.println("enter the details1:");
	String details1= sc.nextLine();
	sc.nextLine();
	String str1[] = details1.split(",");
	
	
	Acc aa = new CurrentAccount(str1[0],str1[1],str1[2],str1[3]);
	aa.display();
	
	break;
}



}

}



	

	


