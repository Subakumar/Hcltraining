
public class Stall {
String name;
String detail;
String ownername;

 Stall(){
	 
 }

public Stall(String name, String detail, String ownername) {
	super();
	this.name = name;
	this.detail = detail;
	this.ownername = ownername;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDetail() {
	return detail;
}

public void setDetail(String detail) {
	this.detail = detail;
}

public String getOwnername() {
	return ownername;
}

public void setOwnername(String ownername) {
	this.ownername = ownername;
}

public Double computeCost(String stallType, Integer squareFeet) {
	double cost =0;
	if(stallType.equals("platinum")) {
		
	 cost = squareFeet*200;
	}
	else if(stallType.equals("diamond")) {
		cost = squareFeet*150;
	}
	else if (stallType.equals("gold")) {
		cost = squareFeet*100;
	}
	else {
		System.out.println("cost is zero");
	}
	return cost;
}
public Double computeCost(String stallType, Integer squareFeet, Integer numberOfTv) {
	double cost =0;
	
	 if(stallType .equals("platinum")) {
		cost = squareFeet*200;
	}
	 else if(stallType.equals("diamond")) {
		 cost = squareFeet*150;
	 }
	 else if(stallType.equals("gold")){
		 cost = squareFeet*100;
	 }
	 else{
		System.out.println ("cost is zero:");
	 }
	 double amount = (numberOfTv*10000)+cost;
	 return amount;
}



	
}


