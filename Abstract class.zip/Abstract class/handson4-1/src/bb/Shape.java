package bb;

public abstract class Shape {
	public abstract Double calculatePerimeter();

}
