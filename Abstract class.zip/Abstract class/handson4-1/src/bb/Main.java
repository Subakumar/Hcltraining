package bb;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Circle c1 = new Circle();
		Square s = new Square();
		Rectangle r = new Rectangle();
		
Scanner sc = new Scanner(System.in);
System.out.println("list of shapes:");
System.out.println("1.Circle");
System.out.println("2.Rectangle");
System.out.println("3.Square");
System.out.println("enter the choice:");
int c = sc.nextInt();
switch(c) {
case 1:

	System.out.println("enter the radius of the circle:");
	float radius = sc.nextFloat();
	c1.setRadius(radius);
	System.out.println("The Perimeter is:"+c1.calculatePerimeter());
	break;

case 2:

	System.out.println("enter the length:");
	float length = sc.nextFloat();
	r.setLength(length);
	System.out.println("enter the breadth:");
	
	float breadth = sc.nextFloat();
	r.setBreadth(breadth);
	System.out.println("The Perimeter is:"+r.calculatePerimeter());
	break;
case 3:

	System.out.println("enter the side:");
	float side = sc.nextFloat();
	s.setSide(side);
	System.out.println("The Perimeter is:"+s.calculatePerimeter());
break;
	}
	}
}
