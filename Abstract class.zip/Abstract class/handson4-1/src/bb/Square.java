package bb;


public  class Square extends Shape{
	float side;
	public Double calculatePerimeter() {
		double area = 4*side;
		return area;
}
	public Square() {
		
	}
	public Square(float side) {
		super();
		this.side = side;
	}
	public float getSide() {
		return side;
	}
	public void setSide(float side) {
		this.side = side;
	}
	
	
}
