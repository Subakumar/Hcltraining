package ff;

public interface Fort {
void distance();
}
