package ff;

public class Murud implements Fort {
int distance;

public Murud() {
	
}

	public int getDistance() {
	return distance;
}

public void setDistance(int distance) {
	this.distance = distance;
}

	public Murud(int distance) {
	super();
	this.distance = distance;
}

	public void distance() {
		System.out.println("The distance is"+getDistance());
	}
}
