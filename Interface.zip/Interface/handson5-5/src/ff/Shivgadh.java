package ff;

public class Shivgadh implements Fort {
	
public void distance() {
	System.out.println("The distance is 100km");
}
}
