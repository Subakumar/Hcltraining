package cc;

public class CarService implements Car {
	
	public void sum(int num) {
		int sum =0,r;
		while(num!=0) {
			r=	num%10;
			sum = sum+r;
			num = num /10;
			}
		if(sum%2==0) {
			System.out.println("you can go on Tuesday, Thursday and Saturday");
		}
		else {
		System.out.println("you can go for servicing on Monday, Wednesday and Friday"); 
		}
	}
	public void year(int years) {
		if(years>5) {
			System.out.println("Car washing is free for you0");
		}
		else {
			System.out.println("car washing is not free for you");
		}
		
	}
	public void brand(String brand) {
		
		if(brand.equals("maruti")) {
			double charge = 5000-(0.05*5000);
			System.out.println("your service charges:"+charge);
		}
		else {
			System.out.println("your service charge:"+5000);
		}
	}

}
