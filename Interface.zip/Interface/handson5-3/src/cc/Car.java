package cc;

public interface Car {
void sum(int num);
void year(int years);
void brand(String brand);
}
