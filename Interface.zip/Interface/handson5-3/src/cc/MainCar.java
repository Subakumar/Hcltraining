package cc;
import java.util.*;

public class MainCar {

	public static void main(String[] args) {
		CarService cs = new CarService();
		int r,sum=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your car number:");
		int num= sc.nextInt();
	 System.out.println("how many years old car do you have:");
		int years = sc.nextInt();
		sc.nextLine();
		System.out.println("car brand:");
		
		String brand = sc.nextLine();
		sc.nextLine();
		
		cs.sum(num);
		cs.year(years);
		cs.brand(brand);
		

	}

}
