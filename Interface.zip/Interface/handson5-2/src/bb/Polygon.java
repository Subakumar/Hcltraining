package bb;

public interface Polygon {

	void calcPeri();
	void calcArea();
	
}
