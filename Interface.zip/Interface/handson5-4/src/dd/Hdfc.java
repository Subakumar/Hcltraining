package dd;


public class Hdfc implements MutualFund{
	int amount;
	int ten;
	public Hdfc() {
		
	}
	
	public Hdfc(int amount, int ten) {
		super();
		this.amount = amount;
		this.ten = ten;
		
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTen() {
		return ten;
	}

	public void setTen(int ten) {
		this.ten = ten;
	}

	
	public void duration() {
		System.out.println("enter the tenure of the SIP:");
		
		
	}
	
	public void amount() {
		
		System.out.println("enter the amount you want to invest:");
	}

	void calcHdfc(Integer amount, Integer ten) {
		double total;
		
	 
	total = (amount*ten*49)/100;
	System.out.println("You will have returns as" +total);
	}
}
